﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;

namespace management_system
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            Console.Clear();
            int num_members = 0;
            int num_users = 0;
            string[] username = new string[100];
            string[] password = new string[100];
            string[] contact_number = new string[100];
            string[] email = new string[100];
            string[] role = new string[100];
            string[] society_member_username = new string[100];
            string[] society_member_email= new string[100];
            string[] society_member_phone =new string[100];

            Readlogindata(username,password,contact_number,email,role,num_users);
            readmemberdata(society_member_username, society_member_email, society_member_phone, num_members);


            int currentSelection = 1;
            while (true)
            {

                displayscreen1();
                subMenuBeforeMainMenu("Login");
                if (currentSelection == 1)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");
                }
                Console.WriteLine("   Sign Up");
                if (currentSelection == 2)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");

                }
                Console.WriteLine("   Sign In");
                if (currentSelection == 3)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");
                }
                Console.WriteLine("   Exit");

                // handle user input

                ConsoleKey keyy = Console.ReadKey().Key;
                if (keyy == ConsoleKey.UpArrow)
                { // up arrow key
                    if (currentSelection > 1)
                    {
                        currentSelection--;
                    }
                    else if (currentSelection == 1)
                    {
                        currentSelection = 3;
                    }
                }

                else if (keyy == ConsoleKey.DownArrow)
                { // down arrow key
                    if (currentSelection < 3)
                    {
                        currentSelection++;
                    }
                    else if (currentSelection == 3)
                    {
                        currentSelection = 1;
                    }
                }

                else if (keyy == ConsoleKey.Enter)
                { // enter key
                    if (currentSelection == 1)
                    {
                        displayscreen1();
                        subMenuBeforeMainMenu("SignUp");
                        signup(username, password, contact_number, role, email, num_users);
                        Console.ReadKey();
                    }
                    else if (currentSelection == 2)
                    {
                        displayscreen1();
                        subMenuBeforeMainMenu("SignIn");
                        signin(num_users, username, password, role, num_members, society_member_username);
                        Console.ReadKey();
                    }
                    else if (currentSelection == 3)
                    {
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice");
                        Console.ReadKey();
                    }
                }
            }
        }

        /* ------------ Sign up/Sign in Menu ----------*/
        static void signup(string[] username, string[] password, string[] contact_number, string[] role, string[] email, int num_users)
        {
            string usern, em, phonen, pass, rolee;

            Console.Write("Enter Username:");
            usern = Console.ReadLine();
            if (is_username_exist(usern, num_users, username))
            {
                Console.WriteLine("Username already exists");
                return;
            }

            Console.Write("Enter Password:");
            pass = Console.ReadLine();

            int numbb = Console.CursorTop;
        input_phone:
            Console.SetCursorPosition(0, numbb);
            printspace();
            Console.SetCursorPosition(0, numbb);
            Console.Write("Enter Phone Number:");
            phonen = Console.ReadLine();
            if (!(isInteger(phonen)))
            {
                Console.WriteLine("Invalid input! Please enter a valid Phone Number. ");
                Console.ReadKey();
                goto input_phone;
            }
            if (is_phone_exist(phonen, num_users, contact_number))
            {
                Console.WriteLine("Phone Number already in use");
                return;
            }

            int numb1 = Console.CursorTop;
        input_email:
            Console.SetCursorPosition(0, numb1);
            printspace();
            Console.SetCursorPosition(0, numb1);
            Console.Write("Enter Email:");
            em = Console.ReadLine();

            Regex emailRegex = new Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
            if (!(emailRegex.IsMatch(em)))
            {
                Console.WriteLine("Invalid email address.");
                Console.ReadKey();
                goto input_email;
            }
            if (is_email_exist(em, num_users, email))
            {
                Console.WriteLine("Email already in use");
                return;
            }

            int numb2 = Console.CursorTop;
        input_role:
            Console.SetCursorPosition(0, numb2);
            printspace();
            Console.SetCursorPosition(0, numb2);
            Console.Write("Enter role(admin/student):");
            rolee = Console.ReadLine();
            if (!(isString(rolee)))
            {
                Console.WriteLine("Invalid input! Please enter a valid Role. ");
                Console.ReadKey();
                goto input_role;
            }

            string new_user = usern;
            string new_pass = pass;
            string new_phone = phonen;
            string new_email = em;
            string new_role = rolee;
            Storinglogindata(new_user, new_pass, new_email, new_phone, new_role);
            username[num_users] = new_user;
            password[num_users] = new_pass;
            email[num_users] = new_email;
            contact_number[num_users] = new_phone;
            role[num_users] = new_role;
            num_users++;
            Console.Write("Sign up Successfully");
        }

        static void signin(int num_users, string[] username, string[] password, string[] role, int num_members, string[] society_member_username)
        {
            string option;
            string un, p;
            Console.Write("Enter Username:");
            un = Console.ReadLine();
            Console.Write("Enter Password:");
            p = Console.ReadLine();

            if (is_valid_user(un, p, num_users, username, password))
            {
                string role1 = get_role(un, num_users, username, role);

                if (role1 == "Admin" || role1 == "admin")
                {
                    Console.WriteLine();
                    Console.WriteLine("        Welcome, " + un + "!");
                    Console.ReadKey();
                    displayscreen();
                    MainMenu();
                    Console.WriteLine("Enter opton: ");
                    option = Console.ReadLine();
                    displayscreen();
                    /*                    AdminsMenu();*/
                    Console.ReadKey();
                }
                else if (role1 == "Student" || role1 == "student")
                {
                    Console.WriteLine("        Welcome, " + un + "!");
                    Console.ReadKey();
                    displayscreen();
                    MainMenu();
                    Console.WriteLine("Enter opton: ");
                    option = Console.ReadLine();
                    displayscreen();
                    StudentMenu(num_users, num_members, society_member_username);
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Invalid role");
                }
            }
            else
            {
                Console.WriteLine("Incorrect Username or Password");
            }
        }

        /* ------------ Validations ----------*/

        static bool is_valid_user(string un, string p, int num_users, string[] username, string[] password)
        {
            for (int i = 0; i < num_users; i++)
            {
                if (username[i] == un && password[i] == p)
                {
                    return true;
                }
            }
            return false;
        }

        static string get_role(string un, int num_users, string[] username, string[] role)
        {
            for (int i = 0; i < num_users; i++)
            {
                if (username[i] == un)
                {
                    return role[i];
                }
            }
            return "";
        }
        static bool is_username_exist(string usern, int num_users, string[] username)
        {
            for (int i = 0; i < num_users; i++)
            {
                if (usern == username[i])
                {
                    return true;
                }
            }
            return false;
        }

        static bool is_phone_exist(string phonen, int num_users, string[] contact_number)
        {
            for (int i = 0; i < num_users; i++)
            {
                if (phonen == contact_number[i])
                {
                    return true;
                }
            }
            return false;
        }

        static bool is_email_exist(string em, int num_users, string[] email)
        {
            for (int i = 0; i < num_users; i++)
            {
                if (em == email[i])
                {
                    return true;
                }
            }
            return false;
        }
        static bool isString(string str)
        {
            char c;
            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsLetter(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }
        static bool isInteger(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsDigit(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }

        /* Menu Functions*/
        static void MainMenu()
        {
            subMenuBeforeMainMenu("Main Menu");
            string option;
            Console.WriteLine("Select the category of the society:");
            Console.WriteLine();
            Console.WriteLine("1.     Sports Societies");
            Console.WriteLine("2.     Programming Societies");
            Console.WriteLine("3.     Creative Art Societies");
            Console.WriteLine("4.     Acedemic Societies");
            Console.WriteLine("5.     Social and Recreational Societies");
            Console.WriteLine("6.     Religious and Spirtual Societies");
            Console.WriteLine("7.     Cultural Societies");
            Console.WriteLine("8.     Artistic Societies");
            Console.WriteLine("9.     Gaming Societies");
            Console.WriteLine("10.Political or activist Societies");
            Console.WriteLine("11.    Exit");
            Console.WriteLine("Enter option:");
            option = Console.ReadLine();
            Console.WriteLine();

            while (true)
            {
                displayscreen();
                if (option == "1")
                {
                    submenu("Sports Society Menu");
                    SportsSocietyMainMenu();
                }
                else if (option == "2")
                {
                    submenu("Programming Society Menu");
                    ProgrammingSocietiesMainMenu();
                }
                else if (option == "3")
                {
                    submenu("Creative Art Society Menu");
                    CreativeArtSocietiesMainMenu();
                }
                else if (option == "4")
                {
                    submenu("Academic Society Menu");
                    AcademicSocietiesMainMenu();
                }
                else if (option == "5")
                {
                    submenu("Social And Recreational Society Menu");
                    SocialAndRecreationalSocietyMainMenu();
                }
                else if (option == "6")
                {
                    submenu("Religious And Spirual Society Menu");
                    ReligiousAndSpiritualSocietyMainMenu();
                }
                else if (option == "7")
                {
                    submenu("Cultural Society Menu");
                    CulturalSocietiesMainMenu();
                }
                else if (option == "8")
                {
                    submenu("Artistic Society Menu");
                    ArtisticSocietiesMainMenu();
                }
                else if (option == "9")
                {
                    submenu("Gaming Society Menu");
                    GamingSocietiesMainMenu();
                }
                else if (option == "10")
                {
                    submenu("Political Society Menu");
                    PoliticalOrActivistSocietiesMainMenu();
                }
                else if (option == "11")
                {
                    return;
                }
                else
                {
                    Console.WriteLine("Invalid choice");
                    Console.ReadKey();
                    displayscreen();
                    MainMenu();
                }
                break;
            }
        }

        
        static void StudentMenu(int num_users, int num_members, string[] society_member_username)
        {
            submenu("Student Menu");
            string option;
            Console.WriteLine("1.     Register Yourself");
            Console.WriteLine("2.     Update Your Information");
            Console.WriteLine("3.     Remove yourself if you are registered:");
            Console.WriteLine("4.     Display the members of Society");
            Console.WriteLine("5.     Display all the socities ");
            Console.WriteLine("6.     Give a feedback about the society");
            Console.WriteLine("7.     See all the upcoming events");
            Console.WriteLine("8.     Check the reviews about the society");
            Console.WriteLine("9.     Submit a request");
            Console.WriteLine("10.    View the society mission and objectives");
            Console.WriteLine("11.    Donate to the society");
            Console.WriteLine("12.    Exit");
            Console.Write("Enter option:");
            option = Console.ReadLine();
            while (true)
            {
                displayscreen();
                if (option == "1")
                {
                    AddMember(num_users, num_members);
                }
                else if (option == "2")
                {
                    UpdateMember(num_members, society_member_username);
                }
                else if (option == "3")
                {
                    RemoveMember(num_members, society_member_username);
                }
                else if (option == "4")
                {
                    DisplayMemberStudent(num_members, society_member_username);
                }
                else if (option == "5")
                {
                    /*                    displaystudentsociety();*/
                }
                else if (option == "6")
                {
                    /*                    giveFeedback();*/
                }
                else if (option == "7")
                {
                    /*                    displayevent();*/
                }
                else if (option == "8")
                {
                    /*                    displayfeedback();*/
                }
                else if (option == "9")
                {
                    /*                    submitRequest();*/
                }
                else if (option == "10")
                {
                    /*                    displaysocietymission();*/
                }
                else if (option == "11")
                {
                    /*                    donateToSociety();*/
                }
                else if (option == "12")
                {
                    MainMenu();
                    Console.ReadKey();
                    displayscreen();
                    StudentMenu(num_users, num_members, society_member_username);
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid option");
                }
                Console.ReadKey();
                displayscreen();
                StudentMenu(num_users, num_members, society_member_username);
                break;
            }
        }

        static void AddMember(int num_users, int num_members)
        {
            int currentyu = Console.CursorTop;

        input_name_again:
            Console.SetCursorPosition(0, currentyu);
            Console.Write("Enter Username: ");
            string username = Console.ReadLine();

            if (!isString(username))
            {
                Console.WriteLine("Invalid input! Please enter a valid Username.");
                Console.ReadKey(true);

                goto input_name_again;
            }

            int currentyr = Console.CursorTop;

        input_email_again:
            Console.SetCursorPosition(0, currentyr);
            Console.Write("Enter Email: ");
            string email = Console.ReadLine();

            Regex emailRegex = new Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
            if (!(emailRegex.IsMatch(email)))
            {
                Console.WriteLine("Invalid email address.");
                Console.ReadKey(true);
                goto input_email_again;
            }

            int currentyp = Console.CursorTop;

        input_phone_again:
            Console.SetCursorPosition(0, currentyp);
            Console.Write("Enter Contact Number: ");
            string phone = Console.ReadLine();

            if (!isInteger(phone))
            {
                Console.WriteLine("Invalid input! Please enter a valid Society Name.");
                Console.ReadKey(true);
                goto input_phone_again;
            }

            if (isString(username) && isInteger(phone) && emailRegex.IsMatch(email))
            {
                /* StoreMemberData(username, email, phone);*/
                num_members++;
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey(true);
        }

        static void UpdateMember(int num_members, string[] society_member_username)
        {
            bool flag = false;
            Console.Write("Enter member's previous username: ");
            string prevUsername = Console.ReadLine();
            Console.Write("Enter member's new username: ");
            string newUsername = Console.ReadLine();

            for (int i = 0; i < num_members; i++)
            {
                if (prevUsername == society_member_username[i])
                {
                    society_member_username[i] = newUsername;
                    /*                    WriteDataInFile1();*/
                    flag = true;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("Member name not found!");
            }
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey(true);
        }

        static void RemoveMember(int num_members, string[] society_member_username)
        {
            bool flag = false;
            Console.Write("Enter Member's name which you want to remove: ");
            string nameToRemove = Console.ReadLine();

            for (int i = 0; i < num_members; i++)
            {
                if (nameToRemove == society_member_username[i])
                {
                    society_member_username[i] = " ";
                    /*                    WriteDataInFile1();*/
                    flag = true;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("Member name not found!");
            }
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey(true);
        }

        static void DisplayMemberStudent(int num_members, string[] society_member_username)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Members");

            for (int i = 0; i < num_members; i++)
            {
                if (society_member_username[i] == " ")
                {
                    continue;
                }

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(society_member_username[i]);
            }
        }
        static void SportsSocietyMainMenu()
        {
            Console.WriteLine("Select any of the given societies: ");
            Console.WriteLine();
            Console.WriteLine("1.     Cricket Club");
            Console.WriteLine("2.     Running Club");
            Console.WriteLine("3.     Athletics Club");
            Console.WriteLine("4.     Vollyball Club");
            Console.WriteLine("5.     Tennis Club");
            Console.WriteLine("6.     Swimming Club");
            Console.WriteLine("7.     Squash Club");
            Console.WriteLine("8.     Running Club");
            Console.WriteLine("9.     Weight Lifting Club");
            Console.WriteLine("10.    Martial Art Society");
            Console.WriteLine("11.    Football Club");
            Console.WriteLine("12.    Badminton Club");
            Console.WriteLine("13.    Basketball Club");
            Console.WriteLine("14.    Hockey Club");
            Console.WriteLine("15.    Cross Country Club");

        }
        static void ProgrammingSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Computer Science Club");
            Console.WriteLine("2.     Coding Society");
            Console.WriteLine("3.     Hacker's Club");
            Console.WriteLine("4.     Programmer's Society");
            Console.WriteLine("5.     Tech Society");
            Console.WriteLine("6.     Software Development Club");
            Console.WriteLine("7.     Web Development Club");
            Console.WriteLine("8.     Mobile Application Development Club");
            Console.WriteLine("9.     Artificial Intelligence Society");
            Console.WriteLine("10.    Cyber Security Club");
            Console.WriteLine("11.    Game Development Club");
        }

        static void CreativeArtSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Photography Club");
            Console.WriteLine("2.     Art Society");
            Console.WriteLine("3.     Film Society");
            Console.WriteLine("4.     Theater Club");
            Console.WriteLine("5.     Creative Writing Society");
            Console.WriteLine("6.     Poetry Club");
            Console.WriteLine("7.     Graphic Design Society");
            Console.WriteLine("8.     Animation Club");
            Console.WriteLine("9.     Fashion Club");
            Console.WriteLine("10.    Craft Society");
        }

        static void AcademicSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Maths Club");
            Console.WriteLine("2.     Science Club");
            Console.WriteLine("3.     Engineering Club");
            Console.WriteLine("4.     Bussiness Club");
            Console.WriteLine("5.     Economics Society");
            Console.WriteLine("6.     Political Science Club");
            Console.WriteLine("7.     Phiosophy Society");
            Console.WriteLine("8.     History Club");
            Console.WriteLine("9.     English Club");
            Console.WriteLine("10.    Literature Society");
            Console.WriteLine("11.    Psychology Club");
            Console.WriteLine("12.    Sociology Club");
            Console.WriteLine("13.    Physics Club");
            Console.WriteLine("14.    Biology Club");
            Console.WriteLine("15.    Chemistry  Club");
        }

        static void SocialAndRecreationalSocietyMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Adventure Club");
            Console.WriteLine("2.     Outdoor Activities Society");
            Console.WriteLine("3.     Travel Club");
            Console.WriteLine("4.     Environmental Club");
            Console.WriteLine("5.     Board Game Society");
            Console.WriteLine("6.     Food Club");
            Console.WriteLine("7.     Human Rights Advocacy Group");
            Console.WriteLine("8.     Student Government Association");
            Console.WriteLine("9.     Debate Club");
            Console.WriteLine("10.    Book Club");
        }

        static void ReligiousAndSpiritualSocietyMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Muslim Student Association");
            Console.WriteLine("2.     Islamic Society");
            Console.WriteLine("3.     Quran Study Group");
            Console.WriteLine("4.     Prayer and Dhikr Circle");
            Console.WriteLine("5.     Da'wah Club");
            Console.WriteLine("6.     Islamic Cultural Society");
            Console.WriteLine("7.     Islamic Education Society");
            Console.WriteLine("8.     Islamic Awareness Society");
            Console.WriteLine("9.     Islamic Finance Society");
            Console.WriteLine("10.     Halaqa(Study Circle)");
        }

        static void CulturalSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     International Student Association");
            Console.WriteLine("2.     African Cultural Society");
            Console.WriteLine("3.     Asian Cultural Society");
            Console.WriteLine("4.     Cultural Society");
            Console.WriteLine("5.     Latin American Cultural Society");
            Console.WriteLine("6.     Middle Eastern Cultural Society");
            Console.WriteLine("7.     Native American Cultural Society");
            Console.WriteLine("8.     Pacific Islander Cultural Society");
            Console.WriteLine("9.     Caribbean Cultural Society");
            Console.WriteLine("10.    South Asian Cultural Society");
            Console.WriteLine("11.    Southeast Asian Cultural Society");
            Console.WriteLine("12.    American Culture Society");
            Console.WriteLine("13.    Australian Cultural Society");
            Console.WriteLine("14.    Canadian Cultural Society");
            Console.WriteLine("15.    New Zealand Cultural Society");
        }

        static void ArtisticSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Photography Club");
            Console.WriteLine("2.     Film Society");
            Console.WriteLine("3.     Drama Club");
            Console.WriteLine("4.     Dance Collective");
            Console.WriteLine("5.     Fine Arts Society");
            Console.WriteLine("6.     Poetry Club");
            Console.WriteLine("7.     Writing Workshop");
            Console.WriteLine("8.     Graphic Design Club");
            Console.WriteLine("9.     Interactive Media Club");
            Console.WriteLine("10.    Digital Art Society");
            Console.WriteLine("11.    Architecture Club");
            Console.WriteLine("12.    Fashion Society");
            Console.WriteLine("13.    Culinary Arts Society");
            Console.WriteLine("14.    Glassblowing Society");
            Console.WriteLine("15.    Performing Arts Society");
        }

        static void GamingSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Esports Club");
            Console.WriteLine("2.     Tabletop Gaming Society");
            Console.WriteLine("3.     Console Gaming Society");
            Console.WriteLine("4.     PC Gaming Society");
            Console.WriteLine("5.     Virtual Reality Club");
            Console.WriteLine("6.     Mobile Gaming Society");
            Console.WriteLine("7.     Retro Gaming Society");
            Console.WriteLine("8.     Adventure Gaming Society");
            Console.WriteLine("9.     Strategy Gaming Society");
            Console.WriteLine("10.    Role-Playing Gaming Society");
            Console.WriteLine("11.    Fighting Game Society");
            Console.WriteLine("12.    Real-Time Strategy Society");
            Console.WriteLine("13.    Survival Gaming Society");
            Console.WriteLine("14.    First-Person Shooter Society");
            Console.WriteLine("15.    Video Game Development Club");
        }

        static void PoliticalOrActivistSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Student Government Association");
            Console.WriteLine("2.     College Republicans");
            Console.WriteLine("3.     Environmental Action Group");
            Console.WriteLine("4.     Advocacy Society");
            Console.WriteLine("5.     Racial Justice League");
            Console.WriteLine("6.     Economic Justice Alliance");
            Console.WriteLine("7.     Disability Rights Group");
            Console.WriteLine("8.     Animal Rights Society");
            Console.WriteLine("9.     Human Rights Campaign");
            Console.WriteLine("10.    Social Justice Alliance");
            Console.WriteLine("11.    Voter Registration and Advocacy Club");
        }

        /* Display Functions */
        static void printspace()
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 200; j++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

        static void displayscreen()
        {
            Console.Clear();
            USMS();
        }

        static void displayscreen1()
        {
            Console.Clear();
            mainUSMS();
        }

        static void subMenuBeforeMainMenu(string submenu)
        {
            string message = submenu + " Menu";
            Console.WriteLine("             " + message);
            Console.WriteLine("-----------------------------------");
        }

        static void submenu(string submenu)
        {
            string message = " Main Menu > " + submenu;
            Console.WriteLine("             " + message);
            Console.WriteLine("-----------------------------------");
        }

        static void USMS()
        {

            Console.WriteLine("     $$\\   $$\\  $$$$$$\\  $$\\      $$\\  $$$$$$\\  ");
            Console.WriteLine("     $$ |  $$ |$$  __$$\\ $$$\\    $$$ |$$  __$$\\ ");
            Console.WriteLine("     $$ |  $$ |$$ /  \\__|$$$$\\  $$$$ |$$ /  \\__|");
            Console.WriteLine("     $$ |  $$ |\\$$$$$$\\  $$\\$$\\$$ $$ |\\$$$$$$\\  ");
            Console.WriteLine("     $$ |  $$ | \\____$$\\ $$ \\$$$  $$ | \\____$$\\ ");
            Console.WriteLine("     $$ |  $$ |$$\\   $$ |$$ |\\$  /$$ |$$\\   $$ |");
            Console.WriteLine("     \\$$$$$$  |\\$$$$$$  |$$ | \\_/ $$ |\\$$$$$$  |");
            Console.WriteLine("      \\______/  \\______/ \\__|     \\__| \\______/ ");
            Console.WriteLine();

        }
        static void mainUSMS()
        {
            Console.WriteLine("     $$$$$$\\   $$$$$$\\   $$$$$$\\  $$$$$$\\ $$$$$$$$\\ $$$$$$$$\\ $$$$$$\\ $$$$$$$$\\  $$$$$$\\     $$\\   $$\\ $$$$$$$$\\ $$$$$$$$\\ ");
            Console.WriteLine("    $$  __$$\\ $$  __$$\\ $$  __$$\\ \\_$$  _|$$  _____|\\__$$  __|\\_$$  _|$$  _____|$$  __$$\\    $$ |  $$ |$$  _____|\\__$$  __|");
            Console.WriteLine("    $$ /  \\__|$$ /  $$ |$$ /  \\__|  $$ |  $$ |         $$ |     $$ |  $$ |      $$ /  \\__|   $$ |  $$ |$$ |         $$ |   ");
            Console.WriteLine("    \\$$$$$$\\  $$ |  $$ |$$ |        $$ |  $$$$$\\       $$ |     $$ |  $$$$$\\    \\$$$$$$\\     $$ |  $$ |$$$$$\\       $$ |   ");
            Console.WriteLine("    $$\\   $$ |$$ |  $$ |$$ |  $$\\   $$ |  $$ |         $$ |     $$ |  $$ |      $$\\   $$ |   $$ |  $$ |$$ |         $$ |   ");
            Console.WriteLine("    \\$$$$$$  | $$$$$$  |\\$$$$$$  |$$$$$$\\ $$$$$$$$\\    $$ |   $$$$$$\\ $$$$$$$$\\ \\$$$$$$  |$$\\\\$$$$$$  |$$$$$$$$\\    $$ |   ");
            Console.WriteLine("     \\______/  \\______/  \\______/ \\______|\\________|   \\__|   \\______|\\________| \\______/ \\__|\\______/ \\________|   \\__|   ");
            Console.WriteLine();

        }

        /*--------File Handling--------*/

        static void Storinglogindata(string new_user, string new_pass, string new_phone, string new_email, string new_role)
        {

            string path = "C:\\OOP\\OOP Lab 1\\management system\\login.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(new_user + "," + new_pass + "," + new_phone + "," + new_email + "," + new_role);
            file.Flush();
            file.Close();
        }

        static void Readlogindata(string[] username, string[] password, string[] email, string[] contact_number, string[] role,int num_users)
        {
            string path = "C:\\OOP\\OOP Lab 1\\management system\\login.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    username[num_users] = getfile(record, 1);
                    password[num_users] = getfile(record, 2);
                    email[num_users] = getfile(record, 3);
                    contact_number[num_users] = getfile(record, 4);
                    role[num_users] = getfile(record, 5);
                    num_users++;

                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }

        static string getfile(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }

        static void storememberdata(string mu, string me, string mp)
        {
            string path = "C:\\OOP\\OOP Lab 1\\management system\\memberdata.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(mu + "," + me + "," + mp);
            file.Flush();
            file.Close();
        }

        static void readmemberdata(string[] society_member_username,string[] society_member_email,string[] society_member_phone,int num_members)
        {
            string path = "C:\\OOP\\OOP Lab 1\\management system\\memberdata.txt";
            if(File.Exists(path))
            {
            StreamReader file = new StreamReader(path);
            string record;
            while((record=file.ReadLine()) != null)
                {
                    society_member_username[num_members] = getfile(record, 1);
                    society_member_email[num_members] = getfile(record, 2);
                    society_member_phone[num_members] = getfile(record, 3);
                    num_members++;
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not exists");
            }
        }
    }
}

