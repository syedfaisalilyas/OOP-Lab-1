﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Lily Task */
        /*    int age;
            float washing_machine_price, toy_prize;
            Console.WriteLine("Enter Age:");
            age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Washing Machine price:");
            washing_machine_price = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Toy Price:");
            toy_prize = float.Parse(Console.ReadLine());*/

            /* Add  */
           /* Console.WriteLine("Enter number 1:");
            int n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter number 2:");
            int n2 = int.Parse(Console.ReadLine());
            add(n1, n2);*/

            /*SignUpSignIn*/
            string[] names = new string[5];
            string[] password = new string[5];
            string path = "C:\\OOP\\OOP Lab 1\\Task1\\password";
            int user_choice = menu();
            Console.Write(user_choice);

            do
            {
                if (user_choice == 1)
                {
                    string n;
                    string p;
                    Console.WriteLine("Enter your name: ");
                    n = Console.ReadLine();
                    Console.WriteLine("Enter your password: ");
                    p = Console.ReadLine();
                    signUp(n, p, path);
                }
                else if (user_choice == 2)
                {
                    string n;
                    string p;
                    bool validUser;
                    Console.WriteLine("Enter your name: ");
                    n = Console.ReadLine();
                    Console.WriteLine("Enter your password: ");
                    p = Console.ReadLine();
                    validUser = signIn(names, password, n, p);
                }
            }
            while (user_choice != 3);
            /*Other Tasks*/
          /*  task1();
            task2();
            task3();
            task4();
            task5();
            task6();
            task7();
            task8(); 
            task9();
            task10();
            task11();
            task12();
            task13();
            task14();
            task15();
            task16();*/

            Console.Read();
        }

        static void task1()
        {
            Console.Write("HELLO WORLD");
            Console.Write("HELLO WORLD");
            Console.Read();
        }
        static void task2()
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Hello World!");
            Console.Read();

        }
        static void task3()
        {
            int variable = 7;
            Console.WriteLine("Variable :");
            Console.WriteLine(variable);
            Console.Read();
        }
        static void task4()
        {
            string variable = "I AM A string";
            Console.WriteLine("Variable :");
            Console.WriteLine(variable);
            Console.Read();
        }
        static void task5()
        {
            char variable = 'A';
            Console.WriteLine("Variable :");
            Console.WriteLine(variable);
            Console.Read();
        }
        static void task6()
        {
            float variable = 4.6F;
            Console.WriteLine("Variable :");
            Console.WriteLine(variable);
            Console.Read();
        }        
        static void task7()
        {
            string str = Console.ReadLine();
            Console.WriteLine("You have inputted:");
            Console.WriteLine(str);
            Console.Read();
        }
        static void task8()
        {
            int variable = int.Parse( Console.ReadLine());
            Console.WriteLine("You have inputted:");
            Console.WriteLine("The number is:");
            Console.WriteLine(variable);
            Console.Read();
        }
        static void task9()
        {
            Console.WriteLine("Enter the floating Point Value:");
            float variable = float.Parse( Console.ReadLine());
            Console.WriteLine("The number is:");
            Console.WriteLine(variable);
            Console.Read();
        }
        static void task10()
        {
            Console.WriteLine("Enter the Length:");
            float length = float.Parse( Console.ReadLine());
            float area = length * length; 
            Console.WriteLine("The Area is:");
            Console.WriteLine(area);
            Console.Read();
        } 
        static void task11()
        {
            Console.WriteLine("Enter the Marks:");
            float marks = float.Parse( Console.ReadLine());
            if(marks>50)
            {
            Console.WriteLine("You are passed!");

            }
            else
            {
                Console.WriteLine("You are failed!");
            }
            Console.Read();
        }
        static void task12()
        {
            for(int i=0;i<5;i++)
            {
            Console.WriteLine("Welcome Jack");
            }
            Console.Read();
        }    
        static void task13()
        {
            int num = 0,sum =0;
            while(num!=-1)
            {
                sum += num;
                Console.WriteLine("Enter Number:");
                num = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("The total sum is {0}", sum);
            Console.Read();
        }   
        static void task14()
        {
            int num = 0,sum =0;
            do
            {
                sum += num;
                Console.WriteLine("Enter Number:");
                num = int.Parse(Console.ReadLine());
            }
            while (num != -1) ;
            Console.WriteLine("The total sum is :" + sum);
            Console.Read();
        } 
        static void task15()
        {
            int[] arr = new int[3];
           for(int i=0;i<3;i++)
            {
                Console.WriteLine("Enter the number" + (i + 1));
                arr[i] = int.Parse(Console.ReadLine());
            }
            int largest = -1;
            for(int i=0;i<3;i++)
            {
                if(arr[i]>largest)
                {
                    largest = arr[i];
                }
            }
            Console.WriteLine("The largest number is:" + largest);
            Console.Read();
        }
        static void task16()
        {
            int[] arr = new int[3];
           for(int i=0;i<3;i++)
            {
                Console.WriteLine("Enter the number" + (i + 1));
                arr[i] = int.Parse(Console.ReadLine());
            }
            int largest = -1;
            for(int i=0;i<3;i++)
            {
                if(arr[i]>largest)
                {
                    largest = arr[i];
                }
            }
            Console.WriteLine("The largest number is:" + largest);
            Console.Read();
        }
        static void CalculateMoney(int age, float price, int toyPrice)
        {
            float money = 0;
            int a = 10;
            for (int i = 1; i <= age; i++)
            {
                if (i % 2 == 0)
                {
                    money += a;
                    money -= 1;
                    a += 10;
                }
                else
                {
                    money += toyPrice;
                }
            }
            if (money >= price)
            {
                Console.WriteLine("Yes! " + (money - price));
            }
            else
            {
                Console.WriteLine("No! " + (price - money));
            }
        }
        static int add(int num1,int num2)
        {
            return num1 + num2;
        }
        static void task17()
        {
            string path = "C:\\OOP\\OOP Lab 1\\Task1";
            if(File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while((record = file.ReadLine()) != null)
                {
                    Console.WriteLine(record);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Path Not exists!");
            }
        } 
        static void task18()
        {
            string path = "C:\\OOP\\OOP Lab 1\\Task1";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine("Hello world");
            file.Flush();
            file.Close();
        }
        static int menu()
            {
                int choice;
                Console.WriteLine("Press 1 for sign up ");
                Console.WriteLine("Press 3 for sign in ");
                Console.WriteLine("Press 3 for exit ");
                choice = int.Parse(Console.ReadLine());
                return choice;
            }
        static void signUp(string username, string password, string path)
            {
                StreamWriter myFile = new StreamWriter(path, true);
                myFile.WriteLine(username + "," + password);
                myFile.Flush();
                myFile.Close();

            }
        static void readDataFromFile(string path, string[] names, string[] password)
            {
                int x = 0;
                if (File.Exists(path))
                {
                    StreamReader myFile = new StreamReader(path);
                    string record;
                    while ((record = myFile.ReadLine()) != null)
                    {
                        names[x] = parseData(record, 1);
                        password[x] = parseData(record, 2);
                        x++;
                        if (x >= 5)
                        {
                            break;
                        }
                    }
                    myFile.Close();
                }
            }       
        static string parseData(string record, int field)
            {
                int commmaCount = 1;
                string item = "";
                for (int x = 0; x < record.Length; x++)
                {
                    if (record[x] == ',')
                    {
                        commmaCount++;
                    }
                    else if (commmaCount == field)
                    {
                        item = item + record[x];
                    }
                }
                return item;
            }
        static bool signIn(string[] names, string[] password, string n, string p)
            {
                bool flag = false;
                for (int x = 0; x < 5; x++)
                {
                    if (names[x] == n && password[x] == p)
                    {
                        flag = true;
                    }
                }
                return flag;
            }


        }
    }



