﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using EZInput;
using System.Threading;
using System.Threading.Tasks;

namespace game
{
    class Program
    {
        static string enemydirection = "down";
        static int PX = 30, PY = 23,E1X = 20,E1Y = 26;
        static char bulletchar = (char)30;
        static int score = 0 , lives = 3 , highscore = 0 , score_count = 0,bulletcount = 0; 
        static int enemy1counter = 0; 
 
        static void Main(string[] args)
        {

            char[,] player_space_ship = new char[7, 13]
    {
    {' ', ' ', ' ', ' ', ' ', ' ', '_', ' ', ' ', ' ', ' ', ' ', ' '},
    {' ', ' ', ' ', ' ', ' ', '/', ' ', '\\', ' ', ' ', ' ', ' ', ' '},
    {' ', ' ', ' ', ' ', '/', ' ', '_', ' ', '\\', ' ', ' ', ' ', ' '},
    {' ', ' ', ' ', '/', ' ', ' ', '_', ' ', ' ', '\\', ' ', ' ', ' '},
    {' ', '_', '/', ' ', ' ', ' ', '_', ' ', ' ', ' ', '\\', '_', ' '},
    {'|', '_', '_', '_', '_', ' ', ' ', ' ', '_', '_', '_', '_', '|'},
    {' ', ' ', ' ', ' ', ' ', '\\', '_', '/', ' ', ' ', ' ', ' ', ' '}
   };


            char[,] enemy1_space_ship = new char[5, 7]{
                                { ' ', ' ', '*', '*', '*', ' ', ' '},
                                { '*', '*', '*', '*', '*', '*', '*'},
                                { '*', '*', '*', '*', '*', '*', '*'},
                                { ' ', '*', '*', '*', '*', '*', ' '},
                                { ' ', ' ', '*', '*', '*', ' ', ' '}
            };

            char[,] Maze = new char[40,180];

            int[] bulletx = new int[100];
            int[] bullety = new int[100];
            bool[] isBulletActice = new bool[100];
            int[] Score= new int[100];
            // loadpic();
            Console.CursorVisible = false;
            Console.Clear();
/*            header();*/
            // System.Threading.Thread.Sleep(700);

            int currentSelection = 1;
            Console.ForegroundColor = ConsoleColor.White;
            while (true)
            {
                Console.Clear();
                Logo();

                if (currentSelection == 1)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write("  >");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("   ");
                }
                Console.WriteLine("   Play");

                if (currentSelection == 2)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write("  >");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("   ");
                }
                Console.WriteLine("   Instructions");

                if (currentSelection == 3)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write("  >");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("   ");
                }
                Console.WriteLine("   Exit");

                // handle user input
                ConsoleKeyInfo key = Console.ReadKey(true);

                if (key.Key == ConsoleKey.UpArrow)
                { // up arrow key
                    if (currentSelection > 1)
                    {
                        currentSelection--;
                    }
                    else if (currentSelection == 1)
                    {
                        currentSelection = 3;
                    }
                }
                else if (key.Key == ConsoleKey.DownArrow)
                { // down arrow key
                    if (currentSelection < 3)
                    {
                        currentSelection++;
                    }
                    else if (currentSelection == 3)
                    {
                        currentSelection = 1;
                    }
                }
                else if (key.Key == ConsoleKey.Enter)
                { // enter key
                    if (currentSelection == 1)
                    {
                        Play(player_space_ship,enemy1_space_ship,Maze,bulletx,bullety,isBulletActice);
                    }
                    else if (currentSelection == 2)
                    {
                        Console.Clear();
                        Instructions();
                        Console.ReadKey(true); // wait for user input before going back to main screen
                    }
                    else if (currentSelection == 3)
                    {
                        Environment.Exit(0);
                    }
                }
            }


        }


        // ----Play---
        static void Play(char[,] player_space_ship, char[,] enemy1_space_ship, char[,] Maze,int[] bulletx,int[] bullety,bool[] isBulletActice)
        {
            /*readscore();*/
            Console.Clear();
            history();
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            bool gamerunning = true;

            Console.Clear();
            /*            readData(Maze);
                        printMaze(Maze);*/

            DrawBorder(Maze);
            /*            controlmenu();
                        updatescore();
                        updatelives();*/
            printspaceship(player_space_ship);
            printenemy1(enemy1_space_ship);
            while (gamerunning)
            {
                enemy1counter++;

                moveenemy1(enemy1_space_ship, Maze,ref gamerunning);

                if (Keyboard.IsKeyPressed(Key.LeftArrow))
              {
                    moveplayerleft(Maze,enemy1_space_ship,player_space_ship,ref gamerunning);
                }
                if (Keyboard.IsKeyPressed(Key.RightArrow))
                {
                    moveplayerright(Maze, enemy1_space_ship, player_space_ship,ref gamerunning);
                }
                if (Keyboard.IsKeyPressed(Key.UpArrow))
                {
                    moveplayerup(Maze, enemy1_space_ship, player_space_ship,ref gamerunning);
                }
                if (Keyboard.IsKeyPressed(Key.DownArrow))
                {
                    moveplayerdown(Maze, enemy1_space_ship, player_space_ship,ref gamerunning);
                }
                if (Keyboard.IsKeyPressed(Key.Space))
                {
                    generatebullet(bulletx,bullety,isBulletActice);

                }
                if (Keyboard.IsKeyPressed(Key.Escape))
                {
                    gamerunning = false;
                }
                if (gamerunning == false)
                {
                    Console.Clear();
                    /*gameover();*/
/*                    Score[score_count] = score;
                    storescore(Score[score_count]);
                    score_count++;*/
                }
                movebullet(bulletx,bullety,isBulletActice,Maze); // to move bullets
                bulletcollisionwidenemy(bulletx, bullety, isBulletActice,enemy1_space_ship,Maze,ref gamerunning);
                Thread.Sleep(15); // to slow the game speed if you want to move the enemies fast the pass the small value to small function like 1 , 2 ,3 and same for slow pass the larger value like 50 or  70
            }
        }


        // ---Collision---
          static void bulletcollisionwidenemy(int[] bulletx, int[] bullety, bool[] isBulletActive, char[,] enemy1_space_ship, char[,] Maze,ref bool gamerunning)
        {
            for (int x = 0; x < bulletcount; x++)
            {
                if (isBulletActive[x] == true)
                {
                    if (bullety[x] == E1Y + 5 && (bulletx[x] == E1X || bulletx[x] == E1X + 1 || bulletx[x] == E1X + 2 || bulletx[x] == E1X + 3 || bulletx[x] == E1X + 4 || bulletx[x] == E1X + 5 || bulletx[x] == E1X + 6))
                    {
                        eraseenemy1();
                        /*     addscore();
                             updatescore();*/
                        Random rnd = new Random();
                        int randomno = rnd.Next();
                        E1X = randomno % 150;
                        E1Y = 2;
                        moveenemy1(enemy1_space_ship,Maze,ref gamerunning);
                    }
                
                }
            }
        }

        static void generatebullet(int[] bulletx,int[] bullety,bool[] isBulletActive)
        {
            bulletx[bulletcount] = PX + 6;
            bullety[bulletcount] = PY - 1;
            isBulletActive[bulletcount] = true;
            Console.SetCursorPosition(bulletx[bulletcount], bullety[bulletcount]);
            Console.Write( bulletchar);
            bulletcount++;
        }
        static void movebullet(int[] bulletx, int[] bullety, bool[] isBulletActive, char[,] Maze)
        {

            for (int x = 0; x < bulletcount; x++)
            {
                /*     if (isBulletActive[x] = true)
                     { */
                char next = Maze[bullety[x] - 1, bulletx[x]]; // get the next possition of bullet if valid the move the bullets else remove it
                if (next == ' ')                                     // to check the conditions if you want to add the collision of bullet with enemy then simply add the enemy char with or (||) operater in if statement  of enemy remove function in if body
                {
                    erasebullet(bulletx[x], bullety[x]);
                    bullety[x] = bullety[x] - 1;
                    printbullet(bulletx[x], bullety[x]);
                }
                else // remove the bullets
                {
                    erasebullet(bulletx[x], bullety[x]);
                    makebulletInactive(x, isBulletActive);
                    deletebullet(x, bulletx, bullety);

                    /*}*/
                }
            }
        }
        static void printbullet(int x, int y)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.SetCursorPosition(x, y);
            Console.Write( bulletchar);
        }
        static void erasebullet(int x, int y)
        {
            Console.SetCursorPosition(x, y);
            Console.Write(' ');
        }
        static void makebulletInactive(int index,bool[] isBulletActive)
        {
            isBulletActive[index] = false;
        }
       static void deletebullet(int index,int[] bulletx,int[] bullety)
        {
            for (int i = index; i < bulletcount; i++)
            {
                bulletx[i] = bulletx[i + 1];
                bullety[i] = bullety[i + 1];
            }
            bulletcount--;
        }




        static void moveenemy1(char[,] enemy1_space_ship, char[,] Maze,ref bool gamerunning)
        {
           
            if (enemydirection == "down")
            {
                char next = Maze[E1Y + 5, E1X ];
                if (next == ' ')
                {
                    eraseenemy1();
                    E1Y++;
                    printenemy1(enemy1_space_ship);
                }
                if (next == '+')
                {
                    eraseenemy1();
                    E1Y = 1;
                    printenemy1(enemy1_space_ship);
                }
                else
                {

                for (int i = 0; i <6 ; i++)
                {
                    next = Maze[E1Y + 5,E1X + i];
                    if (next == '_' || next == '\\' || next == '/' || next == '|')
                    {
                        gamerunning = false;

                        /*      loselife();
                              updatelives();*/
                    }
                }
                }
            }
        }

        // ----- Moving Players Functions ----
        static void moveplayerleft(char[,] Maze,char[,] enemy1_space_ship,char[,] player_space_ship,ref bool gamerunning)
        {
            enemy1counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze,ref gamerunning);
            }
            
            char next = Maze[PY, PX - 1];
            if (next == ' ')
            {
                erasespaceship();
                PX--;
                printspaceship(player_space_ship);
            }
        }
        static void moveplayerright(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning)
        {
            enemy1counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze,ref gamerunning);
            }

            char next = Maze[ PY, PX + 13];
            if (next == ' ')
            {
                erasespaceship();
                PX++;
                printspaceship(player_space_ship);
            }
        }
        static void moveplayerup(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning)
        {
            enemy1counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze,ref gamerunning);
            }

            char next = Maze[ PY - 1,PX];
            if (next == ' ')
            {
                erasespaceship();
                PY--;
                printspaceship(player_space_ship);
            }
        }
        static void moveplayerdown(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning)
        {
            enemy1counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze,ref gamerunning);
            }
            char next = Maze[PY + 7,PX];
            if (next == ' ')
            {
                erasespaceship();
                PY++;
                printspaceship(player_space_ship);
            }
        }


        static void printspaceship(char[,] player_space_ship)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            for (int rows = 0; rows < 7; rows++)
            {
                Console.SetCursorPosition(PX, PY+rows);
                for (int col = 0; col < 13; col++)
                {
                    Console.Write(player_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }
        static void erasespaceship()
        {
            for (int rows = 0; rows < 7; rows++)
            {
                Console.SetCursorPosition(PX , PY+rows );
                for (int col = 0; col < 13; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

         static void printenemy1(char[,] enemy1_space_ship)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            for (int rows = 0; rows < 5; rows++)
            {
                Console.SetCursorPosition(E1X, E1Y + rows);
                for (int col = 0; col < 7; col++)
                {
                    Console.Write(enemy1_space_ship[rows,col]);
                }
                Console.WriteLine();
            }
        }
          static void eraseenemy1()
        {
            for (int rows = 0; rows < 5; rows++)
            {
               Console.SetCursorPosition(E1X, E1Y + rows);
                for (int col = 0; col < 7; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }


        static void readData(char[,] maze2)
        {
            StreamReader fp = new StreamReader("C:\\OOP\\OOP Lab 1\\game\\game\\game\\maze.txt");
            string record;
            int row = 0;
            while ((record = fp.ReadLine()) != null)
            {
                for (int x = 0; x < 180; x++)
                {
                    maze2[row, x] = record[x];
                }
                row++;
            }

            fp.Close();
        }

        static void printMaze(char[,] maze)
        {
            Console.ForegroundColor = ConsoleColor.Gray;

            for (int x = 0; x < maze.GetLength(0); x++)
            {
                for (int y = 0; y < maze.GetLength(1); y++)
                {
                    Console.Write(maze[x, y]);
                }
                Console.WriteLine();
            }
        }

        // ----Drawing border-----
        static void DrawBorder(char[,] Maze)
        {
            Console.ForegroundColor = ConsoleColor.Gray;

            for (int x = 0; x < 40; x++)
            {
                for (int y = 0; y < 180; y++)
                {
                    if (x == 0 || x == 39 || y == 0 || y == 179)
                    {
                        Maze[x, y] = '+';
                    }
                    else if (y == 150 && x < 39 && x > 0)

                    {
                        Maze[x, y] = '+';
                    }
                    else
                    {
                        Maze[x, y] = ' ';
                    }
                    Console.Write(Maze[x, y]);
                }
                Console.WriteLine();
            }

        }

        static void Logo()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n\n\n");
            Console.WriteLine("    $$$$$$\\  $$$$$$$\\   $$$$$$\\   $$$$$$\\  $$$$$$$$\\        $$$$$$\\  $$\\   $$\\  $$$$$$\\   $$$$$$\\ $$$$$$$$\\ $$$$$$$$\\ $$$$$$$\\  ");
            Console.WriteLine("   $$  _$$\\ $$  _$$\\ $$  _$$\\ $$  _$$\\ $$  __|      $$  _$$\\ $$ |  $$ |$$  _$$\\ $$  _$$\\_$$  _|$$  __|$$  _$$\\ ");
            Console.WriteLine("   $$ /  \\_|$$ |  $$ |$$ /  $$ |$$ /  \\|$$ |            $$ /  \\_|$$ |  $$ |$$ /  $$ |$$ /  $$ |  $$ |   $$ |      $$ |  $$ |");
            Console.WriteLine("   \\$$$$$$\\  $$$$$$$  |$$$$$$$$ |$$ |      $$$$$\\          \\$$$$$$\\  $$$$$$$$ |$$ |  $$ |$$ |  $$ |  $$ |   $$$$$\\    $$$$$$$  |");
            Console.WriteLine("    \\__$$\\ $$  _/ $$  _$$ |$$ |      $$  _|          \\_$$\\ $$  _$$ |$$ |  $$ |$$ |  $$ |  $$ |   $$  _|   $$  __$$< ");
            Console.WriteLine("   $$\\   $$ |$$ |      $$ |  $$ |$$ |  $$\\ $$ |            $$\\   $$ |$$ |  $$ |$$ |  $$ |$$ |  $$ |  $$ |   $$ |      $$ |  $$ |");
            Console.WriteLine("   \\$$$$$$  |$$ |      $$ |  $$ |\\$$$$$$  |$$$$$$$$\\       \\$$$$$$  |$$ |  $$ | $$$$$$  | $$$$$$  |  $$ |   $$$$$$$$\\ $$ |  $$ |");
            Console.WriteLine("    \\___/ \\|      \\|  \\| \\__/ \\__|       \\__/ \\|  \\| \\__/  \\__/   \\|   \\__|\\|  \\_|\n\n\n");

            // Reset the console color to default
            Console.ResetColor();
        }

        static void Instructions()
        {
            int x = 40;
            int y = 10;
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("\n\n");

            Console.SetCursorPosition(x + 15, y - 5);
            Console.WriteLine("*********");
            Console.SetCursorPosition(x + 15, y - 4);
            Console.WriteLine("     Space Shooter Game");
            Console.SetCursorPosition(x + 15, y - 3);
            Console.WriteLine("*********");
            Console.WriteLine("\n\n");

            Console.SetCursorPosition(x, y);
            Console.WriteLine("Instructions");
            Console.WriteLine("\n\n");
            Console.SetCursorPosition(x, y + 1);
            Console.WriteLine("1. Use the arrow keys to move your spaceship left and right.");
            Console.SetCursorPosition(x, y + 2);
            Console.WriteLine("2. Press the space bar to fire bullets at the enemy spaceships.");
            Console.SetCursorPosition(x, y + 3);
            Console.WriteLine("3. Avoid getting hit by enemy bullets or colliding with their spaceships.");
            Console.SetCursorPosition(x, y + 4);
            Console.WriteLine("4. Shoot down as many enemy spaceships as possible to score points.");
            Console.SetCursorPosition(x, y + 5);
            Console.WriteLine("5. The game will display your score on the right side of the console.");
            Console.SetCursorPosition(x, y + 6);
            Console.WriteLine("6. Press any key to go back to the main screen.");
        }

        static void Loading()
        {
            // this is just a loading bar

            Console.SetCursorPosition(87, 26);
            Console.WriteLine("LOADING....");
            int x, y;

            // HORIZONTAL
            //--UP
            x = 87;
            y = 27;
            Console.SetCursorPosition(x, y);
            for (int z = 0; z <= 30; z++)
            {
                Console.Write((char)205);
            }
            //--Down
            y = 29;
            Console.SetCursorPosition(x, y);
            for (int z = 0; z <= 30; z++)
            {
                Console.Write((char)205);
            }

            // VERTICAL
            //--Right
            x = 117;
            Console.SetCursorPosition(x, y);
            for (y = 28; y < 29; y++)
            {
                Console.SetCursorPosition(x, y);
                Console.Write((char)186);
            }
            //--Left
            x = 87;
            Console.SetCursorPosition(x, y);
            for (y = 28; y < 29; y++)
            {
                Console.SetCursorPosition(x, y);
                Console.Write((char)186);
            }

            // Corners
            Console.SetCursorPosition(87, 27);
            Console.Write((char)201); // UP -LEFT
            Console.SetCursorPosition(117, 27);
            Console.Write((char)187); // UP - RIGHT
            Console.SetCursorPosition(87, 29);
            Console.Write((char)200); // DOWN -LEFT
            Console.SetCursorPosition(117, 29);
            Console.Write((char)188); // DOWN RIGHT

            // Loading bar
            for (int cargar = 88; cargar < 117; cargar++)
            {
                Console.SetCursorPosition(cargar, 28);
                Console.Write((char)178);

                Thread.Sleep(50);
            }
        }

        static void history()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;

            // Story
            int x = 48, y = 3;
            Console.SetCursorPosition(x, y);
            Console.Write("WELCOME TO SPACE SHOOTER GAME");
            x = 12; y = 5;
            Console.SetCursorPosition(x, y);
            Console.Write("The galaxy is under Attack, an alien race called 'The Yincas' has invaded our solar");
            Console.SetCursorPosition(x, y + 1);
            Console.Write(" system and it is taking the earth's resources.  If we don't do something the human");
            Console.SetCursorPosition(x, y + 2);
            Console.Write("race will disappear.");

            Console.SetCursorPosition(x, y + 4);
            Console.Write("YOUR MISION:");
            Console.SetCursorPosition(x, y + 5);
            Console.Write("Destroy some yinca ships to show them we are not afraid");
            Console.SetCursorPosition(x, y + 7);
            Console.Write("VEHICLE:");
            Console.SetCursorPosition(x, y + 8);
            Console.Write("You've got the StarFighter spaceship, use the left,right,up and down keys to move it");
            Console.SetCursorPosition(x, y + 10);
            Console.Write("TECHNOLOGY:");
            Console.SetCursorPosition(x, y + 11);
            Console.Write("We have a laser gun, to shoot it use the spaceBar");
            x = 33; y = 20;
            Console.SetCursorPosition(x, y);
            Console.Write("OK SOLDIER, HIT ENTER TO JUMP INTO THE ACTION!!!");

            Loading(); // LOADING BAR

            Console.ReadKey(true); // WAIT FOR ANY KEY TO BE PRESSED TO CLEAN THE SCREEN
            Console.Clear();
        }

    }
}
